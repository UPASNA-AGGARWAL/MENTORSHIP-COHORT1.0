// Create a list of post objects
const posts = [
  {
      imageSrc: "IMAGE1.jpg",
      username: "user123",
      likes: 150,
      caption: "Beautiful sunset"
  },
  // Add more posts here
];

// Function to render posts on the feed
function renderPosts() {
  const feed = document.querySelector(".feed");
  feed.innerHTML = "";

  posts.forEach((post) => {
      const postDiv = document.createElement("div");
      postDiv.classList.add("post");

      const postImage = document.createElement("img");
      postImage.src = post.imageSrc;
      postImage.alt = "Post Image";

      const postInfo = document.createElement("div");
      postInfo.classList.add("post-info");

      const username = document.createElement("div");
      username.classList.add("username");
      username.textContent = post.username;

      const likes = document.createElement("div");
      likes.classList.add("likes");
      likes.textContent = `Likes: ${post.likes}`;

      const caption = document.createElement("div");
      caption.classList.add("caption");
      caption.textContent = post.caption;

      postInfo.appendChild(username);
      postInfo.appendChild(likes);
      postInfo.appendChild(caption);

      postDiv.appendChild(postImage);
      postDiv.appendChild(postInfo);

      feed.appendChild(postDiv);
  });
}

// Initial rendering of posts
renderPosts();

// Simulate liking a post
function likePost(postIndex) {
  posts[postIndex].likes++;
  renderPosts();
}

// Adding event listeners for post likes
document.addEventListener("DOMContentLoaded", () => {
  const likeButtons = document.querySelectorAll(".likes");
  likeButtons.forEach((button, index) => {
      button.addEventListener("click", () => {
          likePost(index);
      });
  });
});