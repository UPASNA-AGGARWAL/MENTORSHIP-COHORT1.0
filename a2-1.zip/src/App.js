import React from "react";
import "./styles.css";
import CounterFunctional from "./CounterFunctional"; // Relative path to CounterFunctional.js
import CounterClass from "./CounterClass"; // Relative path to CounterClass.js

function App() {
  return (
    <div className="App">
      <h1>Hello CodeSandbox</h1>
      <h2>Start editing to see some magic happen!</h2>

      <div className="counter-container">
        <CounterFunctional />
        <CounterClass />
      </div>
    </div>
  );
}

export default App;
